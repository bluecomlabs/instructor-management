// Prism - is a lightweight, extensible syntax highlighter, built with modern web standards in mind: https://prismjs.com/
import "prismjs/prism.js";
import "prismjs/components/prism-bash.js";
import "prismjs/components/prism-javascript.js";
import "prismjs/components/prism-scss.js";
import "prismjs/components/prism-css.js";
import "prismjs/components/prism-json.js";
import "prismjs/plugins/normalize-whitespace/prism-normalize-whitespace.js";
